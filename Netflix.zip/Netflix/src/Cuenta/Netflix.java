package Cuenta;

import java.util.Scanner;

public class Netflix {

	public static void main(String[] args) {	
		Scanner lector=new Scanner(System.in);		
	String correo,contrs�;
	int opcion = 0,plan,Opc,pin = 0,cuenta,pago,ver = 0,tipo = 0,Accion = 0,capitulo = 0,opc = 0,terror = 0,ciencF;
int cap;
String[] accion;
	
do {
	   System.out.print("              ");
	   System.out.print("              ");
	   System.out.println("****NETFLIX****");
		System.out.println();
		System.out.println("Tiene cuenta o desea crear una?");
		System.out.println("opcion1= Crear cuenta");
		System.out.println("opcion2= Iniciar sesion");
	Opc=lector.nextInt();
	if(Opc==1) {
		 
			System.out.println("Crear cuenta");
			System.out.println("Email: ");
			correo=lector.next();
			System.out.println("Contrase�a: ");
			contrs�=lector.next();
			System.out.println("***************"+correo+"");
			System.out.println("**Selecciona tu plan***");
			System.out.println("1  Basico = 7.99$");
			System.out.println("2  Estandar= 10.99$");
			System.out.println("3  Premium= 13.99$");
			plan=lector.nextInt();
			System.out.println("Selecciona tu forma de pago");
			System.out.println("1 Mensual");
			System.out.println("2 Quincenal");
			
			pago=lector.nextInt();
			System.out.println("Sus pagos seran:   "+pago+" del plan "+plan);
			System.out.println("Su pin es : 2222");
			System.out.println("***Iniciar sesion***");
			System.out.println();
			System.out.println(correo+"Ingrese su pin");
			pin=lector.nextInt();
			if(pin<2222) {
				while(pin<2222){
				System.out.println("Vuelve a intentarlo");
				System.out.println(correo+"   "+"Ingrese pin");
				pin=lector.nextInt();
				
				}//while
			}//if 2
			
		}//if 1
	else {
		if(Opc==2) {
			System.out.println("**Usuarios***");
			System.out.println("1  Jos125");
			System.out.println("2  AroonD");
			System.out.println("Elige tu cuenta");
			cuenta=lector.nextInt();
			System.out.println(cuenta+"   "+"Ingrese pin");
			pin=lector.nextInt();
			if(pin<2222 && pin>2222) {
				while(pin<2222 && pin>2222){
				System.out.println("Vuelve a intentarlo");
				System.out.println(cuenta+"   "+"Ingrese pin");
				pin=lector.nextInt();
				
				}
			}
			
			System.out.println("Que desea ver");
			System.out.println("1 Series");
			System.out.println("2 Peliculas");
			System.out.println("Ingrese su opcion: ");
			ver=lector.nextInt();
			
			//////////////////////////////////////////////////////
			if (ver==1) {
			System.out.println("Que tipo de serie desea ver?");
			System.out.println("Elige el de tu preferencia");
					 String tipoSerie[]=new String[2];
					 tipoSerie[0]="1  Accion";
					 tipoSerie[1]="2  Ciencia ficcion";
					 for(int i=0;i<2;i++) {
						  System.out.println(tipoSerie[i]);
							tipo=lector.nextInt();
					 }
				if(tipo==2) {
					System.out.println("Ciencia Ficcion");
				     accion=new String[2];
					  accion[0]="1  Games of Thrones";
					  accion[1]="2  CSI: Miami";
					
					for(int i1= 0; i1 < 2; i1++) {
						System.out.println(accion[i1]);	
						}
						System.out.println("�Cu�l serie desea ver?");
						Accion=lector.nextInt();
						if(Accion==1) {
						
					    System.out.println("TGames of Thrones");
					    System.out.println("-------------------------");
					    System.out.println("�Qu� capitulo desea ver?");
						
					    String Cap1[] = new String [2];
						Cap1[0]="Capitulo 1";
						Cap1[1]="Capitulo 2";
						for(int i1= 0; i1 < 2; i1++) {
							System.out.println(Cap1[i1]);
						}
						 capitulo=lector.nextInt();
						   if(capitulo==1){					    
						    
						    do {
						    System.out.println("Reproducciendo Capitulo 1....");
						    System.out.println("Capitulo finalizado, presione 1 para salir");
						    opc=lector.nextInt();
						    }while(capitulo==0);
						    if(opc==1) {
						    }
						    }
						   }
						}//if
				
						    /////////////////////////////////////////////////////////
						    
						    if(capitulo==2){
						    	do {
						   
						    System.out.println("Reproducciendo Capitulo 2....");
						    System.out.println("Capitulo finalizado, presione 1 para salir");
						    opc=lector.nextInt();
						    }while(opc==0);
						    if(opc==1) {
							}}
						    
						   
//////////////////////////////////////////////////////////////
						    if(Accion==2) {
							    System.out.println("CSIS: Miami");
							    System.out.println("------------------------------");
							    System.out.println("�Qu� capitulo desea ver?");
								
							    String Cap[]= new String [2];
								Cap[0]="Capitulo 1";
								Cap[1]="Capitulo 2";

								for(int i1= 0; i1 < 2; i1++) {
									System.out.println(Cap[i1]);
								
								  capitulo=lector.nextInt();}
								    
								   if(capitulo==1)
								    {
								    do {
								    System.out.println("Reproducciendo Capitulo 1....");
								    System.out.println("Capitulo finalizado, presione 1 para salir");
								    opc=lector.nextInt();
								    }while(capitulo==0);
								    if(opc==1) {
								    }
								    }
								   }} 
								    /////////////////////////////////////////////////////////
								    if(capitulo==2)
								    { do {
								   
								    System.out.println("Reproducciendo Capitulo 2....");
								    System.out.println("Capitulo finalizado, presione 1 para salir");
								    opc=lector.nextInt();
								    }while(opc==0);
								    if(opc==1) {
									}}

						
						}
				}
						
		

			/////////////////////////////////////////////////////////////////
//////////////////////////////////////////////				///////////////////////////////
				if(ver==2) {
					System.out.println("");
					System.out.println("Que tipo de pelicula desea ver?");
							 String tipoPelicula[]=new String[3];
							 tipoPelicula[0]="1  Terror";
							 tipoPelicula[1]="2  Ciencia ficcion";
							 for(int i=0;i<2;i++) {
								  System.out.println(tipoPelicula[i]);
								  tipo=lector.nextInt();
							  }
						if(tipo==1) {
							System.out.println("Terror");
							String peliculasTerror[]=new String[2];
							peliculasTerror[0]="1   Annabelle";
							peliculasTerror[1]="2   Sinister";
							 for(int i=0;i<2;i++) {
								  System.out.println(peliculasTerror[i]);
							  }
				
							System.out.println("Que pelicula desea ver?");
							terror=lector.nextInt();
							if(terror==1) {
								System.out.println("**Annabelle***");
								    System.out.println("-------------------------");
								  
									    System.out.println("Reproducciendo ....");
									    System.out.println(" finalizado, presione 1 para salir");
									    opc=lector.nextInt();
									    }while(capitulo==0);
									    if(opc==1) {
									    }
									    }
									   }
						
				    ///////////////////////////////
			///////////////////////////////////			
				 if(terror==2) {
					    System.out.println("Sinister");
					    System.out.println("------------------------------");
						
						    do {
						    System.out.println("Reproducciendo ....");
						    System.out.println("finalizado, presione 1 para salir");
						    opc=lector.nextInt();
						    }while(capitulo==0);
						    if(opc==1) {
						    }
						    }
					
/////////////////////////////////////////////////////////////////////////
						    ///////////////////////////////////////
				 if(tipo==2) {
					 System.out.println("Ciencia Ficcion");
					 String peliculasCienciaFiccion[]=new String[4];
					 peliculasCienciaFiccion[0]="1   Avenger End Game";
					 peliculasCienciaFiccion[1]="2   Interestelar";
					 
					 for(int i=0;i<2;i++) {
						  System.out.println(peliculasCienciaFiccion[i]);
					 }
					 System.out.println("Que pelicula desea ver?");
					 ciencF=lector.nextInt();
					 if(ciencF==1) {
							    System.out.println("Avenger End Game");
							    System.out.println("------------------------------");
								    do {
								    System.out.println("Reproducciendo ...");
								    System.out.println();
								    System.out.println("finalizado, presione 1 para salir");
								    opc=lector.nextInt();
								    }while(capitulo==0);
								    if(opc==1) {
				     }
				  }
								   
					 if(ciencF==2) {
						    System.out.println("Interestelar");
						    System.out.println("------------------------------");
							    do {
							    System.out.println("Reproducciendo ...");
							    System.out.println();
							    System.out.println("finalizado, presione 1 para salir");
							    opc=lector.nextInt();
							    }while(capitulo==0);
							    if(opc==1) {
			     }
			  }			
							
		}
		
	
	System.out.println("Desea volver a usar el programa?");
	System.out.println("Opcion 1= continuar");
	System.out.println("Opcion 2 = salir");
}while(opcion==2);
	opcion=lector.nextInt();
	if (opcion==2) {
		System.out.println("cerrando sesion");
	}
	
	}//cierre main
}//cierre public
		
		

		
